#pragma once
#include "Configuration.h"

void allumerDELInterne(int p_duree);
void eteindreDELInterne(int p_duree);
