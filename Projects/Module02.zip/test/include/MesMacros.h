#pragma once

#define calculerMaximum(a,b) ((a)>(b)?(a):(b))
#define calculerMinimum(a,b) ((a)<(b)?(a):(b))