#pragma once
#include <Arduino.h>

#define DUREE_DEL_ALLUMEE 100
#define DUREE_DEL_ETEINTE 500
