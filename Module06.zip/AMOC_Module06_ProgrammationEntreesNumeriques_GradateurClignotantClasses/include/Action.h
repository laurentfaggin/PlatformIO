#pragma once
#include <Arduino.h>

class Action{
public:
    virtual void executer() = 0;
};